# CC_Checker
This Python based program checks your given Credit Card List and returns if it is Live or Dead . This is a 1req Checker so it does not charge your card , just validates it.Do let me know if the API is dead , i will try to change it. XD

*This Checker is VPN based checker , so if you get proxy error, change your IP and try again.(This feature is not available now , check V1.0 for the feature)

# How to Use the Checker :-

 - Load the list.txt text will your cards.
 - Change the variable in the program to the number of cards you uploaded in the list.txt (Default value if 100)
 - Whenever you are replacing the list.txt , make the content of num.txt to 0
 - Add the proxies to proxies.txt
 - Start the Checker , that is cchecker.py
 - All the CCN and CVV cards will be saved in the success.txt file.
 - All working proxies will be added to checkedproxies file
 
 *Since this is a proxy based checker , it's slow . If you want the VPN based checker , check the releases.

# Contact
If you have any difficulties with the Checker , contact me on Telegram [@hellosre](https://t.me/hellosre)

#BuyMeACoffee

You can buy me a coffee or something at [here](https://www.buymeacoffee.com/srevarun)

Share Lives XD
